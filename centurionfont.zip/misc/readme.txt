This font is PERSONAL USE only.
If you want to use this font for COMMERCIAL,
You need a commercial license that can be purchased here:

https://www.creativework69.com/

Thank you :)